class env{
  public:
  int gate;
  float a, d, s, r, out;
  int _aarg, _darg, _sarg, _rarg;               //current values to stop parameter jumping
  enum states{att, dec, sus, rel};
  states state;
  env();
  void set_a(int aarg);
  void set_d(int darg);
  void set_s(int sarg);
  void set_r(int rarg);
  void set_gate(int garg);
  void set_amp(float amparg);
  int process(void);
};

env::env(){
  out = 0;
  a = 1000.0;
  d = 1.0;
  s = 2000.0;
  r = 1.0;
  gate = 0;
  state = rel;
}

void env::set_a(int aarg){
  if(abs(_aarg - aarg) < 100.0){
    a = (4096.0 - float(aarg));
    a = a/1048.0;
    a = a * a;
    a = a * a;
    //a = a / 8;
    _aarg = aarg;
  }
}

void env::set_d(int darg){
  if(abs(_darg - darg) < 100.0){
    d = (4096.0 - float(darg));
    d = d/1048.0;
    d = d * d;
    d = d * d;
    d = d / 64;
    _darg = darg;
  }
}

void env::set_s(int sarg){         
  if(abs(_sarg - sarg) < 100.0){      //doesn't seem to be working
    s = sarg;
    _sarg = sarg;
  }
}

void env::set_r(int rarg){
  if(abs(_rarg - rarg) < 100.0){
    r = (4096.0 - float(rarg))/4096.0;
    r = r * r;
    //r = r * 3;
    _rarg = rarg;
  }
}

void env::set_gate(int garg){
  gate = garg;
}

int env::process(void){

  switch(state){
    case att:
      if(gate == 1){
        out += a;
        if(out > 4096.0){
          out = 4096.0;
          state = dec;
        }
      }else{
        state = rel;
      }
      break;
    case dec:
      if(gate == 1){
        out -= d*(1 + (out - s)/300);
        if(out <= s){
          out = s;
          state = sus;
        }
      }else{
        state = rel;
      }
      break;
    case sus:
      if(gate == 1){
        out = s;
      }else{
        state = rel;
      }
      break;
    case rel:
      if(gate == 0){
        out -= r*(1 + (out)/300);
        if(out <= 0){
          out = 0;
        }
      }else{
        state = att;
      }
      break;
  }

  return int(out);
  
}
