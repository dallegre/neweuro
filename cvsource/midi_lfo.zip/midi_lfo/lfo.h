class lfo{
  public:
  int toggle, wave, out;
  int _warg;
  float i, freq, amp;
  int _farg, _aarg;              //hope changing from float to int doesn't cause problems.
  lfo();
  void set_freq(int   farg);
  void set_wave(int   warg);
  void set_amp(int    aarg);
  int process(void);
  int randnum;
};

lfo::lfo(){
  wave = 2;
  freq = 0.0005;
  i = 0.0;
  toggle = 1;
  amp = 0.5;
  out = 0;
}

void lfo::set_freq(int farg){
  if(abs(_farg - farg) < 100.0){
    float freqtemp = farg/4096.0;
    freqtemp = freqtemp * freqtemp;
    freqtemp = freqtemp * freqtemp;
    freqtemp = freqtemp * 0.01;
    freq = freqtemp;
    _farg = farg;
  }
}

void lfo::set_wave(int warg){
  if(abs(_warg - warg) < 100.0){
    if(warg < 1365){
      wave = 0;
    }else if(warg >= 1365 && warg < 2730){
      wave = 1;
    }else if(warg >= 2730){
      wave = 2;
    }
    _warg = warg;
  }
}

void lfo::set_amp(int aarg){
  if(abs(_aarg - aarg) < 100.0){
    amp = aarg/4096.0;
    _aarg = aarg;
  }
}

int lfo::process(void){
  
  i += freq;
  
  if (i > 2.0) {
    i -= 2.0;
    toggle *= -1;
    randnum = rand() % 4096;
  }

  if(wave == 0){                                              //random
    
    out = randnum;
    
  }else if(wave == 1){                                        //saw
    
    out = 4096 - (int)(2048.0 * i);
    
  }else if(wave == 2){                                        //triangle

    out = 4096 - (int)(2048.0 * i);
    if(out < 2048){
      out = (int)(2048.0 * i);
    }
    out = out - 2048;
    //out = out * 2;
    
  }

  return amp*out;
  
}
