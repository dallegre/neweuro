class lfo{
  public:
  int toggle, wave, out, sync;
  float i, freq;
  int _farg, _warg, _sarg;              //hope changing from float to int doesn't cause problems.
  lfo();
  void set_freq(int   farg);
  void set_wave(int   warg);
  void set_sync(int   aarg);
  int process(void);
  void process_sync(void);
  int randnum;
};

lfo::lfo(){
  wave = 2;
  freq = 0.0005;
  i = 0.0;
  toggle = 1;
  sync = 0;
  out = 0;
}

void lfo::set_freq(int farg){
  if(abs(_farg - farg) < 100.0){
    float freqtemp = (farg+1000)/4096.0;
    freqtemp = freqtemp * freqtemp;
    freqtemp = freqtemp * freqtemp;
    freqtemp = freqtemp * freqtemp;    
    freqtemp = freqtemp * 0.2;
    freq = freqtemp;
    _farg = farg;
  }
}

void lfo::set_wave(int warg){
  if(abs(_warg - warg) < 100.0){
    if(warg < 1365){
      wave = 0;
    }else if(warg >= 1365 && warg < 2730){
      wave = 1;
    }else if(warg >= 2730){
      wave = 2;
    }
    _warg = warg;
  }
}

void lfo::set_sync(int sarg){
  if(abs(_sarg - sarg) < 100.0){
    if(sarg > 2048){
      sync = 1;
    }else{
      sync = 0;
    }
    _sarg = sarg;
  }
}

int lfo::process(void){
  
  i += freq;
  
  if (i > 2.0) {
    //i -= 2.0;
    i = 0.0;
    randnum = rand() % 4096;
  }

  if(wave == 0){                                              //random
    
    out = randnum;
    
  }else if(wave == 1){                                        //saw
    
    out = 4096 - (int)(2048.0 * i);
    
  }else if(wave == 2){                                        //triangle

    out = 4096 - (int)(2048.0 * i);
    if(out < 2048){
      out = (int)(2048.0 * i);
    }
    out = out - 2048;
    out = out * 2;
    
  }

  return out;
  
}

void lfo::process_sync(void){
  if(sync == 1){
    i = 0.0;
    randnum = rand() % 4096;
  }
}
